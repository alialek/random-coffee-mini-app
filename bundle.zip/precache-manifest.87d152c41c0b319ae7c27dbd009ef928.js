self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "255707f61ce8a27e9c4e5bf461715486",
    "url": "./index.html"
  },
  {
    "revision": "06be839577241b074769",
    "url": "./static/css/2.6326594c.chunk.css"
  },
  {
    "revision": "e3343d6210da24e6966f",
    "url": "./static/css/main.b74c1731.chunk.css"
  },
  {
    "revision": "06be839577241b074769",
    "url": "./static/js/2.60936b2b.chunk.js"
  },
  {
    "revision": "e6ba14e9a581767c78034312d2d23123",
    "url": "./static/js/2.60936b2b.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e3343d6210da24e6966f",
    "url": "./static/js/main.4909a6a2.chunk.js"
  },
  {
    "revision": "f1e5981a6ba2352e688a",
    "url": "./static/js/runtime-main.728d551d.js"
  },
  {
    "revision": "935a06d43a49a68ec0e7fd4edfd19e55",
    "url": "./static/media/coffee.935a06d4.png"
  },
  {
    "revision": "38f1816e7d8eb67b7af1f6173eae6d9a",
    "url": "./static/media/donut.38f1816e.png"
  },
  {
    "revision": "fbbf518f0ea1911e85dcc433f6ece801",
    "url": "./static/media/gear.fbbf518f.png"
  },
  {
    "revision": "c5c9c85342debebedbdf70b114c76370",
    "url": "./static/media/handshake.c5c9c853.png"
  },
  {
    "revision": "432707c7863ede29b9a7cfd99b6cad20",
    "url": "./static/media/hi.432707c7.png"
  },
  {
    "revision": "81feae82602eced998ac53eae1196836",
    "url": "./static/media/post1.81feae82.jpg"
  },
  {
    "revision": "4060a682166df38fe72bd38719604a36",
    "url": "./static/media/post2.4060a682.jpg"
  },
  {
    "revision": "955e60d93fb03dc43d985775fff4a7f9",
    "url": "./static/media/syntax.955e60d9.png"
  }
]);
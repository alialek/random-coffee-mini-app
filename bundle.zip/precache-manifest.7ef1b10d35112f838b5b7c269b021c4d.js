self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "87f28c832d2201c2428c7084b1afaae4",
    "url": "/index.html"
  },
  {
    "revision": "3f01a44e281a0715510a",
    "url": "/static/css/2.6326594c.chunk.css"
  },
  {
    "revision": "342eb513fd856482dfac",
    "url": "/static/css/main.fddc9616.chunk.css"
  },
  {
    "revision": "3f01a44e281a0715510a",
    "url": "/static/js/2.db9f069f.chunk.js"
  },
  {
    "revision": "e6ba14e9a581767c78034312d2d23123",
    "url": "/static/js/2.db9f069f.chunk.js.LICENSE.txt"
  },
  {
    "revision": "342eb513fd856482dfac",
    "url": "/static/js/main.79edc2b6.chunk.js"
  },
  {
    "revision": "08e9bc4b06afa15063f8",
    "url": "/static/js/runtime-main.571e2403.js"
  },
  {
    "revision": "935a06d43a49a68ec0e7fd4edfd19e55",
    "url": "/static/media/coffee.935a06d4.png"
  },
  {
    "revision": "0df2f593d257a68a7f729d825b1ea31e",
    "url": "/static/media/coin.0df2f593.png"
  },
  {
    "revision": "38f1816e7d8eb67b7af1f6173eae6d9a",
    "url": "/static/media/donut.38f1816e.png"
  },
  {
    "revision": "fbbf518f0ea1911e85dcc433f6ece801",
    "url": "/static/media/gear.fbbf518f.png"
  },
  {
    "revision": "c5c9c85342debebedbdf70b114c76370",
    "url": "/static/media/handshake.c5c9c853.png"
  },
  {
    "revision": "432707c7863ede29b9a7cfd99b6cad20",
    "url": "/static/media/hi.432707c7.png"
  },
  {
    "revision": "81feae82602eced998ac53eae1196836",
    "url": "/static/media/post1.81feae82.jpg"
  },
  {
    "revision": "4060a682166df38fe72bd38719604a36",
    "url": "/static/media/post2.4060a682.jpg"
  }
]);
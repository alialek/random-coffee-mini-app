self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "587db8a0bd668477114b305c211bab1b",
    "url": "/index.html"
  },
  {
    "revision": "5b9148166a622c693060",
    "url": "/static/css/2.6326594c.chunk.css"
  },
  {
    "revision": "09d1d13df831171887e8",
    "url": "/static/css/main.9ae8bf08.chunk.css"
  },
  {
    "revision": "5b9148166a622c693060",
    "url": "/static/js/2.20a79b29.chunk.js"
  },
  {
    "revision": "e6ba14e9a581767c78034312d2d23123",
    "url": "/static/js/2.20a79b29.chunk.js.LICENSE.txt"
  },
  {
    "revision": "09d1d13df831171887e8",
    "url": "/static/js/main.b5c6d44b.chunk.js"
  },
  {
    "revision": "08e9bc4b06afa15063f8",
    "url": "/static/js/runtime-main.571e2403.js"
  },
  {
    "revision": "935a06d43a49a68ec0e7fd4edfd19e55",
    "url": "/static/media/coffee.935a06d4.png"
  },
  {
    "revision": "38f1816e7d8eb67b7af1f6173eae6d9a",
    "url": "/static/media/donut.38f1816e.png"
  },
  {
    "revision": "fbbf518f0ea1911e85dcc433f6ece801",
    "url": "/static/media/gear.fbbf518f.png"
  },
  {
    "revision": "c5c9c85342debebedbdf70b114c76370",
    "url": "/static/media/handshake.c5c9c853.png"
  },
  {
    "revision": "432707c7863ede29b9a7cfd99b6cad20",
    "url": "/static/media/hi.432707c7.png"
  },
  {
    "revision": "81feae82602eced998ac53eae1196836",
    "url": "/static/media/post1.81feae82.jpg"
  },
  {
    "revision": "4060a682166df38fe72bd38719604a36",
    "url": "/static/media/post2.4060a682.jpg"
  },
  {
    "revision": "955e60d93fb03dc43d985775fff4a7f9",
    "url": "/static/media/syntax.955e60d9.png"
  }
]);
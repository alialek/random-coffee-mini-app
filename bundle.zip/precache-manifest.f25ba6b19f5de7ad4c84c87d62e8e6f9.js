self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "28aabed627ed48e7bcca48ac94451b87",
    "url": "/index.html"
  },
  {
    "revision": "c6ee432edc191a58adff",
    "url": "/static/css/2.6326594c.chunk.css"
  },
  {
    "revision": "fd051360cad9a45cb7db",
    "url": "/static/css/main.cc072831.chunk.css"
  },
  {
    "revision": "c6ee432edc191a58adff",
    "url": "/static/js/2.fd39afcb.chunk.js"
  },
  {
    "revision": "e6ba14e9a581767c78034312d2d23123",
    "url": "/static/js/2.fd39afcb.chunk.js.LICENSE.txt"
  },
  {
    "revision": "fd051360cad9a45cb7db",
    "url": "/static/js/main.4fa6690c.chunk.js"
  },
  {
    "revision": "08e9bc4b06afa15063f8",
    "url": "/static/js/runtime-main.571e2403.js"
  },
  {
    "revision": "935a06d43a49a68ec0e7fd4edfd19e55",
    "url": "/static/media/coffee.935a06d4.png"
  },
  {
    "revision": "0df2f593d257a68a7f729d825b1ea31e",
    "url": "/static/media/coin.0df2f593.png"
  },
  {
    "revision": "fbbf518f0ea1911e85dcc433f6ece801",
    "url": "/static/media/gear.fbbf518f.png"
  },
  {
    "revision": "c5c9c85342debebedbdf70b114c76370",
    "url": "/static/media/handshake.c5c9c853.png"
  },
  {
    "revision": "432707c7863ede29b9a7cfd99b6cad20",
    "url": "/static/media/hi.432707c7.png"
  },
  {
    "revision": "e9b65033661047c63eb0bc5c00e9fc68",
    "url": "/static/media/post1.e9b65033.jpg"
  },
  {
    "revision": "983b56110026e9aa04fa99a25b18ede2",
    "url": "/static/media/post2.983b5611.jpg"
  }
]);